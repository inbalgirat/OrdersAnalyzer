import java.math.BigDecimal
import java.time.DayOfWeek
import java.time.LocalDateTime
class OrdersAnalyzer {


    data class Order(val orderId: Int, val creationDate: LocalDateTime, val orderLines: List<OrderLine>)

    data class OrderLine(val productId: Int, val name: String, val quantity: Int, val unitPrice: BigDecimal)


    fun totalDailySales(orders: List<Order>): Map<DayOfWeek, Int> {
        val result = HashMap<DayOfWeek, Int>();

        for (order in orders) {
            val dayOfWeek = order.creationDate.dayOfWeek;
                var count = 0;
                for (line in order.orderLines) {
                    count += line.quantity;
                }
                var existCount = result.get(dayOfWeek);
                if (existCount !== null) {
                    var newCount = count + existCount;
                    result.set(dayOfWeek,newCount);
                } else {
                    result.set(dayOfWeek,count);
                }
        }
        return result.toSortedMap();
    }
}


fun main(args: Array<String>) {

    var o1: OrdersAnalyzer.Order = OrdersAnalyzer.Order(554, LocalDateTime.of(2017,3,25,10,35,20),
        listOf(OrdersAnalyzer.OrderLine(9872, "Pencil", 3, BigDecimal(3)))
    );

    var o2: OrdersAnalyzer.Order = OrdersAnalyzer.Order(554, LocalDateTime.of(2017,3,25,10,35,20),
        listOf(OrdersAnalyzer.OrderLine(9872, "Pencil", 2, BigDecimal(3)), OrdersAnalyzer.OrderLine(9872, "Pencil", 1, BigDecimal(1)))
    );

    var o3: OrdersAnalyzer.Order = OrdersAnalyzer.Order(555, LocalDateTime.of(2017,3,27,10,35,20),
        listOf(OrdersAnalyzer.OrderLine(9872, "Pencil", 4, BigDecimal(3)),
            OrdersAnalyzer.OrderLine(9872, "Pencil", 3, BigDecimal(3)),
            OrdersAnalyzer.OrderLine(9872, "Pencil", 1, BigDecimal(3)))
    );

    var o4: OrdersAnalyzer.Order = OrdersAnalyzer.Order(554, LocalDateTime.of(2017,3,20,10,35,20),
        listOf(OrdersAnalyzer.OrderLine(9872, "Pencil", 7, BigDecimal(3)),
            OrdersAnalyzer.OrderLine(9872, "Pencil", 2, BigDecimal(3)))
    );

    var o5: OrdersAnalyzer.Order = OrdersAnalyzer.Order(554, LocalDateTime.of(2017,3,26,10,35,20),
        listOf(OrdersAnalyzer.OrderLine(9872, "Pencil", 4, BigDecimal(3)),
            OrdersAnalyzer.OrderLine(9872, "Pencil", 5, BigDecimal(3)))
    );


    var list: ArrayList<OrdersAnalyzer.Order> = ArrayList();
    list.add(o1);
    list.add(o2);
    list.add(o3);
    list.add(o4);
    list.add(o5);

    var run: OrdersAnalyzer = OrdersAnalyzer();
    println(run.totalDailySales(list));
}